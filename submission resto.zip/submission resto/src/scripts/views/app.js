import UrlParser from '../routes/url-parser';
import routes from '../routes/routes';

class App {
  constructor({ button, drawer, content }) {
    this._button = button;
    this._drawer = drawer;
    this._content = content;
  }

  async renderPage() {
    const url = UrlParser.parseActiveUrlWithCombiner();
    const page = routes[url];
    if (this._content) {
      this._content.innerHTML = await page.render();
      await page.afterRender();
    } else {
      console.error('Content element not found');
    }
  }
}

export default App;
