const Home = {
  async render() {
    return `
        <div class="hero">
          <div class="hero__inner">
            <h1 class="hero__title">Dicoding Restaurant</h1>
            <p class="hero__tagline">A taste of home</p>
          </div>
        </div>
        <h1>List Of Restaurant</h1>
        <div id="restaurant-list"></div>
      `;
  },

  // eslint-disable-next-line no-empty-function
  async afterRender() {
  },
};

export default Home;
