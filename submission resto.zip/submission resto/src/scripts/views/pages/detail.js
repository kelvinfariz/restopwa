import UrlParser from '../../routes/url-parser';
import RestaurantSource from '../../data/restaurant-source';
import { createRestaurantDetailTemplate } from '../templates/template';
// import FavoriteButtonInitiator from '../../utils/favorite-button-initiator';

const Detail = {
  async render() {
    return `
        <div class="detail_container">
          <h1 class="detail_head">About Restaurant</h1>
          <div id="detail_content" class="detail_content"></div>
          <div id="favoriteButtonContainer"></div>
        </div>
      `;
  },

  async afterRender() {
    const url = UrlParser.parseActiveUrlWithoutCombiner();
    const data = await RestaurantSource.detailRestaurant(url.id);
    const detailContentContainer = document.querySelector('#detail_content');
    detailContentContainer.innerHTML = createRestaurantDetailTemplate(data.restaurant);
  },
};

export default Detail;
