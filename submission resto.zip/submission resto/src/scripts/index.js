import 'regenerator-runtime';
import '../styles/main.css';
import App from './views/app';
import ListResto from './utils/listresto';
import Detail from './views/pages/detail';

const hamburgerButtonElement = document.querySelector('.hamburger');
const navListElement = document.querySelector('.nav__list');
if (hamburgerButtonElement && navListElement) {
  hamburgerButtonElement.addEventListener('click', (event) => {
    event.stopPropagation();
    navListElement.classList.toggle('show');
  });
}

const mainElement = document.querySelector('main');
if (mainElement) {
  mainElement.addEventListener('click', () => {
    if (navListElement) {
      navListElement.classList.remove('show');
    }
  });
}

const app = new App({
  button: document.querySelector('#hamburgerButton'),
  drawer: document.querySelector('#navigationDrawer'),
  content: document.querySelector('#mainContent'),
});

window.addEventListener('hashchange', () => {
  app.renderPage();
});

window.addEventListener('load', () => {
  app.renderPage();
  if (window.location.hash.includes('/detail/')) {
    const detail = new Detail();
    const mainContent = document.getElementById('mainContent');
    if (mainContent) {
      mainContent.innerHTML = '';
      mainContent.appendChild(detail.render());
      detail.afterRender();
    }
  } else {
    const listResto = new ListResto();
    const mainContent = document.getElementById('mainContent');
    if (mainContent) {
      mainContent.innerHTML = '';
      mainContent.appendChild(listResto.render());
      listResto.afterRender();
    }
  }
});
