import API_ENDPOINT from '../globals/api-endpoints';

class RestaurantSource {
  static async getAllRestaurants() {
    const response = await fetch(API_ENDPOINT.LIST);
    const responseJson = await response.json();
    return responseJson.restaurants;
  }

  static async detailRestaurant(id) {
    const response = await fetch(API_ENDPOINT.DETAIL(id));
    const responseJson = await response.json();
    console.log(responseJson); // Tambahkan log ini untuk memeriksa struktur data
    return responseJson.restaurant; // Pastikan ini mengembalikan objek restoran yang benar
  }
}

export default RestaurantSource;
