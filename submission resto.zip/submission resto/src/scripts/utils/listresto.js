import RestaurantSource from '../data/restaurant-source';

function createRestaurantItemTemplate(data) {
  const imageUrl = `https://restaurant-api.dicoding.dev/images/medium/${data.pictureId}`;

  return `
    <div class="restaurant">
      <a href="/#/detail/${data.id}">
        <img src="${imageUrl}" alt="${data.name}" class="restaurant-image">
        <div class="restaurant-info">
          <h2>${data.name}</h2>
          <p>${data.description}</p>
          <p>City: ${data.city}</p>
          <p>Rating: ⭐️ ${data.rating}</p>
        </div>
      </a>
    </div>
  `;
}

class ListResto {
  static async render() {
    return `
      <h1>List Of Restaurant</h1>
      <div id="restaurant-list" class="restaurant-list"></div>
    `;
  }

  static async afterRender() {
    try {
      const restaurants = await RestaurantSource.getAllRestaurants();
      const restaurantListElement = document.querySelector('#restaurant-list');
      restaurantListElement.innerHTML = '';

      restaurants.forEach((data) => {
        restaurantListElement.innerHTML += createRestaurantItemTemplate(data);
      });
    } catch (error) {
      console.error('Error rendering restaurant list:', error);
      const restaurantListElement = document.querySelector('#restaurant-list');
      restaurantListElement.innerHTML = `<p>Error: ${error.message}</p>`;
    }
  }
}

export default ListResto;
